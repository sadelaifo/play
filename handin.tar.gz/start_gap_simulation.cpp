#include <iostream>
#include <stdlib.h>     /* srand, rand */
#include <time.h>       /* time */
#include <chrono>
#include <ctime>
#include <stdio.h>
#include <string.h>
#include <new>          // std::bad_alloc
#include <thread>
#include <vector>
#include <mutex>          // std::mutex
#include <queue>
#include "utils.h"
#include <assert.h>     /* assert */
using namespace std;
static inline void swap(uint64_t* a, uint64_t* b);
void shuffle_map_table(uint64_t* mt, const uint64_t size);

const uint64_t z = 4;
const uint64_t block_size = 64;
const uint64_t period = 100;
std::vector<std::thread> consumer;
int main(int argc, char** argv) {
	srand((unsigned int) time(NULL));

//	for (int i = 0; i < 1000; i++) {
//		cout << rand() % 1000 << endl;
//	}
//	return 0;

        if (argc < 5) {
                std::cout << "ERROR, enter wmax, level, groups, threads\n";
                return 1;
        }
	const uint64_t wmax 		= (uint64_t)atoi(argv[1]);
	const uint64_t level 		= (uint64_t)atoi(argv[2]);
	const uint64_t groups 		= (uint64_t)atoi(argv[3]);
	const uint64_t num_threads 	= (uint64_t)atoi(argv[4]);
	const uint64_t nodes 		= (1 << level) - 1;
	const uint64_t size 		= nodes;
	const uint64_t memory_size 	= (nodes + groups) * z * block_size;
	const uint64_t thres 		= nodes / 100;
	const uint64_t group_size 	= nodes / groups + 1;

	assert(groups < nodes);
	
	uint64_t* 	map_table;
	uint64_t*  	group_writes;
	uint64_t*  	group_size_vector;
	uint64_t*  	group_counter;
	uint64_t*  	start;
	uint64_t*  	gap;
	uint64_t** 	pa;
	config_t 	config;

	std::mutex* 		  group_lock;
//  	pthread_mutex_t*	group_lock;
        std::queue <uint64_t> 	  queue;

	std::cout << "Enter wmax, level, groups, threads\n";
	std::cout << wmax << " " << level << " " << groups << " " << num_threads << std::endl;

	// initialize configuration values
	std::cout << "Initializing ...\n";
	try {
		map_table		= new uint64_t  [nodes];
		group_writes 	  	= new uint64_t  [groups];
		group_size_vector 	= new uint64_t  [groups];
		group_counter 		= new uint64_t  [groups];
		start 			= new uint64_t  [groups];
		gap			= new uint64_t  [groups];
		pa                      = new uint64_t* [groups];
		group_lock              = new std::mutex[groups];
	} catch (std::bad_alloc & ba) {
		std::cerr << "bad_allocation caught: " << ba.what() << '\n';
		return 1;
	}
        memset(group_writes,  0, sizeof(uint64_t) * groups);
        memset(group_counter, 0, sizeof(uint64_t) * groups);
	memset(start, 	      0, sizeof(uint64_t) * groups);
        for (uint64_t i = 0; i < groups; i++) {
		try {
                pa[i] = new uint64_t[group_size + 1];
		} catch (std::bad_alloc& ba) {
			std::cerr << "bad allocation caught: " << ba.what() << std::endl;
			return 1;
		}
                memset(pa[i], 0, sizeof(uint64_t) * (group_size + 1));
                group_size_vector[i] = group_size;
		gap[i] = group_size + 1;
        }
        group_size_vector[groups - 1] 	= nodes - (groups - 1) * group_size + 1;
	gap[groups - 1] 		= nodes - (groups - 1) * group_size + 2;

	// initialize & randomly permutate memory lines
	shuffle_map_table(map_table, size);

	config.pa 		= pa;
	config.group_counter 	= group_counter;
	config.group_size 	= group_size_vector;
	config.nodes 		= nodes;
	config.groups 		= groups;
	config.map_table	= map_table;
	config.level		= level;
	config.total_threads 	= num_threads;
	config.wmax 		= wmax;
	config.thres 		= thres;
	config.finished_threads = 0;
	config.group_lock 	= group_lock;
	config.period 		= period;
	config.req_queue 	= &queue;
	config.group_writes 	= group_writes;
        config.failed_nodes 	= 0;
        config.start 		= start;
        config.gap   		= gap;

	// create new producer threa
	printf("Finish initialization\n");
        printf("Begin simulating start-gap\n");

	auto start_time = std::chrono::system_clock::now();	

	std::thread producer(produce_path_oram_requests, &config);
	
	// create new consumer threads
	for (uint64_t i = 0; i < num_threads; i++) {
		consumer.push_back(std::thread(consume_path_oram_requests, &config));
	}

	// wait for return status
	for (uint64_t i = 0; i < consumer.size(); i++) {
		consumer[i].join();
	}

	producer.join();

	auto end_time = std::chrono::system_clock::now();
	std::chrono::duration<double> elapsed_seconds = end_time - start_time;

	// count the total # of writes
	uint64_t c = 0;
	for (uint64_t i = 0; i < groups; i++) {
		c += config.group_writes[i];
	}

	double lifetime = (double) c / (double) wmax / (double) (nodes + groups);
	// finish up
	// print status & free memory
	std::cout << "elapsed time is " << elapsed_seconds.count() << std::endl;
	std::cout << "total write is " << c << std::endl;
	std::cout << "memory size:        " << (memory_size >> 20) << "MB" << std::endl;
	std::cout << "level:              " << level << std::endl;
	std::cout << "nodes:              " << nodes << std::endl;
	std::cout << "ideal total write : " << wmax * nodes << std::endl;
	std::cout << "wmax=" << wmax << "; level=" << level << "; group=" << groups << " percent lifetime :  " << lifetime << std::endl;
	// this line is only used for do_sg.sh to easily grep the lifetime 
	std::cout << "pgs=" << lifetime << std::endl;
	delete []group_lock;
	delete []group_writes;
	delete []group_counter;
	delete []group_size_vector;
	delete []map_table;
	delete []start;
	delete []gap;
	for (uint64_t i = 0; i < groups; i++) {
		delete [] pa[i];
	}
	delete []pa;
}

static inline void swap(uint64_t* a, uint64_t* b) {
	uint64_t c = *a;
	*a = *b;
	*b = c;
	return;
}

void shuffle_map_table(uint64_t* mt, const uint64_t size) {
	for (uint64_t i = 0; i < size; i++) {
		mt[i] = i;
	}
	uint64_t tmp = 0;
	// randomly permutate array
	for (uint64_t i = 0; i < size; i++) {
		tmp = (uint64_t) rand() % size;
		swap(&mt[i], &mt[tmp]);
	}
}
