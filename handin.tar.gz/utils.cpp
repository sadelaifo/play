#include "utils.h"

inline void leaf_range(const uint64_t level, uint64_t &from, uint64_t &to) {
	from = (uint64_t) (1 << (level - 1)) - 1;
	to   = (uint64_t) (1 << level) - 2;
}

void produce_path_oram_requests(config_t* config) {
	std::queue<uint64_t>* 	 req_queue 	= config->req_queue;
	uint64_t 		 req 		= 0;
	uint64_t 		 from		= 0;
	uint64_t 		 to		= 0;
	const uint64_t 		 level		= config->level;
	leaf_range(level, from, to);

	const uint64_t 		 range		= to - from;
	assert (to >= from);
	while (1) {
		std::unique_lock<std::mutex> lck(config->mutex);

		// fill in path oram request
		while (req_queue->size() < queue_uint64_thres) {
			req = (uint64_t) rand() % range + from;	// the produced node is virtual node
			// we need to translate 2 times when simulating start-gap
			while (req > 0) {
				req_queue->push(req);
				req = (req - 1) / 2;
			}
		}
		config->cv_consumer.notify_all();
		config->cv_producer.wait(config->mutex);

		// after being woken up, check whether all consumers are finished or not.
		// if yes, then quit
		uint64_t finished_threads = config->finished_threads;
		if (finished_threads == config->total_threads) {
			return;
		} else if (finished_threads > config->total_threads) {
			printf("ERROR, finished threads > number of threads specified\n");
			return;
		}
	}
	return;
}

void consume_path_oram_requests(config_t* config) {
	std::queue<uint64_t>* req_queue = config->req_queue;
	uint64_t la = 0;
	while (1) {
		// get a job from request queue
		if (true) { 
			std::unique_lock<std::mutex> lck(config->mutex);
			while (req_queue->size() <= 0) {
				config->cv_producer.notify_one();
				config->cv_consumer.wait(config->mutex);
			}
			la = req_queue->front();
			req_queue->pop();
		} 
		// then process the job
		if (increment_memory_line(la, config) == 1) {
			(config->finished_threads)++;
			config->cv_producer.notify_one();
			return;
		}
	}
	config->cv_producer.notify_one();
	std::cout << "error, shouldn't come here \n";
	return;
}

// return 1 if # of failed nodes > threshold
// return 0 on a success start-gap update of memory
int increment_memory_line(uint64_t la, config_t* config) {
	const uint64_t  nodes 		= config->nodes;
	const uint64_t  wmax 		= config->wmax;
	const uint64_t  thres		= config->thres;
	const uint64_t  group_size_max 	= (nodes / config->groups + 1);
	la = config->map_table[la];
	uint64_t  group_id      =  la / group_size_max;
	uint64_t* pa            =  config->pa[group_id];
	uint64_t* start 	= &config->start[group_id];
	uint64_t* gap 		= &config->gap[group_id];

	// this entire function is locked by a per-group-lock.
	std::unique_lock<std::mutex> lck(config->group_lock[group_id]);

	// perform start-gap logic
	la = la % group_size_max;
	uint64_t tmp_pa = (la + *start) % config->group_size[group_id];
	tmp_pa = tmp_pa < *gap ? tmp_pa : tmp_pa + 1;
        (config->group_counter[group_id])++;
        (config->group_writes[group_id])++;
        (pa[tmp_pa])++;
	if (pa[tmp_pa] >= wmax) {
		(config->failed_nodes)++;
		pa[tmp_pa] = 0;
	}
        if (config->failed_nodes >= thres) {
                return 1;
        }
	if (config->group_counter[group_id] % config->period == 0) {
		(*gap)--;
		if (*gap == 0) {
			*gap = config->group_size[group_id];
			*start = (*start + 1) % (*gap);
		}
	}

	return 0;
}

inline uint64_t binarySearch(uint64_t arr[], uint64_t l, uint64_t r, uint64_t x)
{
	if (r > l) {
		uint64_t mid = l + (r - l) / 2;

		if (arr[mid] == x) {
			return mid;
		}
		if (arr[mid] > x) {
			return binarySearch(arr, l, mid, x);
		}
		return binarySearch(arr, mid + 1, r, x);
	}
	if (r == l) {
		return r;
	}
	printf("ERROR, binary search encountered error\n");
	return (uint64_t) -1;
}
