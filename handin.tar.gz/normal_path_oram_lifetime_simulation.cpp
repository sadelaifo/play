//#include "pch.h"
#include <bits/stdc++.h> 

#include <iostream>
#include <math.h>
#include <stdlib.h>     /* srand, rand */
#include <time.h>       /* time */
#include <chrono>
#include <ctime>    
#include <stdio.h>
#include <string.h>
#include <set>
using namespace std;

const uint64_t z = 4;
const uint64_t block_size = 64;

int main(int argc, char** argv)
{
	if (argc < 3) {
		cout << "ERROR, enter wmax, level\n";
		return 1;
	}
	printf("Enter Wmax, level\n");
	uint64_t wmax = (uint64_t)atoi(argv[1]);
	uint64_t level = (uint64_t)atoi(argv[2]);;
	std::cout << wmax << " " << level << std::endl;
	uint64_t nodes = (1 << level) - 1;
//	uint64_t phi = 100;                               // gap movement period
	const uint64_t memory_size = nodes * z * block_size;

	std::set<pair<uint64_t, uint64_t> > s;
	srand((unsigned int) time(NULL));
//	uint64_t count = 0;
	uint64_t thres = nodes / 100;
	uint64_t* nodes_per_level = new uint64_t[level];
	uint64_t** memory = new uint64_t*[level];
	uint64_t failed_nodes = 0;
	for (uint64_t i = 0; i < level; i++) {
		memory[i] = new uint64_t[1 << i];
		memset(memory[i], 0, sizeof(uint64_t) * (1 << i));
		nodes_per_level[i] = 1 << i;
	}
	uint64_t leaf_access;
	// begin simulation
	auto start = std::chrono::system_clock::now();
	uint64_t c = 0;
	while (1) {
		// generate random accesses
		leaf_access = (uint64_t) rand() % nodes_per_level[level - 1];
		for (int i = (int)level - 1; i >= 0; i--) {
			assert(leaf_access < nodes_per_level[i]);
			memory[i][leaf_access]++;
			if (memory[i][leaf_access] >= wmax) {
				failed_nodes++;
				memory[i][leaf_access] = 0;
			}
			if (failed_nodes >= thres) {
				goto L1;
			}
			c++;
			leaf_access = leaf_access >> 1;
		}
	}
L1:
	auto end = std::chrono::system_clock::now();
	std::chrono::duration<double> elapsed_seconds = end - start;
	double lifetime = (double) c / (double) wmax / (double) nodes;

	std::cout << "elapsed time is " << elapsed_seconds.count() << std::endl;
	std::cout << "total write is " << c << std::endl;

	cout << "status: " << endl;
	cout << "memory size: 	     " << (double)(memory_size >> 20) << "MB" << endl;
	cout << "level:       	     " << level << endl;
	cout << "nodes:	             " << nodes << endl;
	cout << "ideal total write : " << wmax * nodes << endl;
	cout << "level=" << level << "; " <<  "percent lifetime :  " << lifetime << endl;
	cout << "pgs=" << lifetime << endl;
	return 0;
}

