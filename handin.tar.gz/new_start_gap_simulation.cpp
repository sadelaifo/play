#include <iostream>
#include <math.h>
#include <fstream>
#include <stdlib.h>     /* srand, rand */
#include <time.h>       /* time */
#include <chrono>
#include <ctime>
#include <stdio.h>
#include <string.h>
//#include <set>
#include <new>          // std::bad_alloc
//#include <vector>
#include <queue>
//#include "utils.h"
#include <assert.h>     /* assert */

using namespace std;
static inline void swap(uint64_t* a, uint64_t* b);
int read_config_file(uint64_t& level, uint64_t& nodes, uint64_t* mt);
uint64_t translate_group_id(uint64_t groups, uint64_t pid, uint64_t group_id);
uint64_t min(uint64_t a, uint64_t b);
uint64_t max(uint64_t a, uint64_t b);
const uint64_t max_threads = 4;
const uint64_t z = 4;
const uint64_t block_size = 64;
const uint64_t period = 1;
int main(int argc, char** argv) {
	srand((unsigned int) 200);
	if (argc < 2) {
		std::cout << "ERROR, Enter id (0-" << max_threads - 1 << ") for this process\n";
		return 1;
	}
	if (argc < 5) {
		std::cout << "ERROR, enter id, wmax, groups, threads\n";
                return 1;
	}

	uint64_t level;
	uint64_t nodes;
	uint64_t* map_table;
        if (read_config_file(level, nodes, map_table) == 1) {
                return 1;
        }

	const uint64_t pid 		= (uint64_t)atoi(argv[1]);
        const uint64_t wmax             = (uint64_t)atoi(argv[2]);
        const uint64_t groups           = (uint64_t)atoi(argv[3]);
        const uint64_t size             = nodes;
        const uint64_t memory_size      = (nodes + groups) * z * block_size;
        const uint64_t thres            = nodes / 100;
        const uint64_t group_size_max   = nodes / groups + 1;
	const uint64_t groups_per_thread = groups / max_threads;
	uint64_t groups_this_thread = groups_per_thread;
	uint64_t failed_nodes = 0;
	uint64_t from;
        uint64_t to;
	if (groups % max_threads - pid > 0) {
		groups_this_thread = groups_per_thread + 1;
		from = groups_this_thread * pid * group_size_max;
		to = max(nodes, from + groups_this_thread * group_size_max); 
	} else {
		from = (groups_this_thread - 1 ) * (groups % max_threads) * group_size_max + groups_this_thread * (groups % max_threads - pid) * group_size_max;
		to   = max(nodes, from + groups_this_thread * group_size_max);
	}
	assert(groups < nodes);
	assert(groups >= max_threads);
	const uint64_t leaf_from = (uint64_t) (1 << (level - 1)) - 1;
	const uint64_t leaf_to = (uint64_t) (1 << level) - 2;
	const uint64_t leaf_range = leaf_to - leaf_from;
	// read configuration mapping table
	uint64_t** pa;
	pa = new uint64_t*[groups_this_thread];
	for (int i = 0;i < groups_this_thread; i++) {
		pa[i] = new uint64_t [group_size_max];
		memset(pa[i], 0, sizeof(uint64_t) * group_size_max);
	}
	// begin start gap simulation
	
	auto start_time = std::chrono::system_clock::now();
	uint64_t* requests = new uint64_t [level];
	uint64_t* start = new uint64_t [groups_this_thread];
	uint64_t* gap = new uint64_t [groups_this_thread];
	uint64_t* group_counter = new uint64_t[groups_this_thread];
	uint64_t counter = 0;
	memset(group_counter, 0, sizeof(uint64_t) * groups);
	memset(start, 0, sizeof(uint64_t) * groups);
	memset(gap, 0, sizeof(uint64_t) * groups);
	while (failed_nodes < thres) {
		uint64_t leaf_id = (uint64_t) rand() % leaf_range + leaf_from;
		for (uint64_t i = 0; i < level; i++) {
			requests[i] = leaf_id;
			uint64_t la = map_table[leaf_id];
			uint64_t group_id = la / group_size_max;
			uint64_t group_offset = translate_group_id(groups, pid, group_id);
			la = la % group_size_max;
			uint64_t tmp_pa = (la + start[group_offset]) % nodes;
			tmp_pa = tmp_pa < gap[group_offset] ? tmp_pa : tmp_pa + 1;
			int status = 0;
			if (failed_nodes > thres) {
				status = 1;
				goto L1;
			}
			if (pa[group_offset][tmp_pa] >= wmax) {
				failed_nodes++;
				pa[group_offset][tmp_pa] = 0;
			} else {
				(group_counter[group_offset])++;
//				(group_writes[group_id])++;
				(pa[group_offset][tmp_pa])++;
				if (group_counter[group_offset] % period == 0) {
					gap[group_offset]--;
					if (gap[group_offset] == 0) {
						gap[group_offset] = group_size_max;
						start[group_offset] = (start[group_offset] + 1) % gap[group_offset];
					}
				}
			}
L1:

			counter++;
			leaf_id = (leaf_id - 1) / 2;
			if (counter > 100000) {
				cout << "Total writes this thread:  " << counter << endl;
				cout << "Total failed nodes so far: " << failed_nodes << endl;
				cout << "Number of groups monitoring: "  << groups_this_thread << endl;
			}
		}
	}
}

int read_config_file(uint64_t& level, uint64_t& nodes, uint64_t* mt) {
	ifstream inputFile("config.txt");
	if (inputFile.fail()) {
		cout << "ERROR: cannot open config.txt\n";
		return 1;
	}
	inputFile >> level >> nodes;
	try {
		mt = new uint64_t [nodes];
	} catch (std::bad_alloc & ba) {
		std::cerr << "bad_allocation caught: " << ba.what() << '\n';
		return 1;
	}
	assert(nodes == ((1 << level) - 1));
	for (uint64_t i = 0; i < nodes; i++) {
		inputFile >> mt[i];
	}
	return 0;
}

uint64_t min(uint64_t a, uint64_t b) {
	if (a > b) {
		return b;
	}
	return a;
}

uint64_t max(uint64_t a, uint64_t b) {
	if (a < b) {
		return b;
	}
	return a;
}

uint64_t translate_group_id(uint64_t groups, uint64_t pid, uint64_t group_id) {
	if (groups % max_threads - pid > 0) {
		return group_id % (groups / max_threads + 1);
	} else {
		return (group_id - groups % max_threads * (groups / max_threads + 1)) % (groups / max_threads);
	}
}

static inline void swap(uint64_t* a, uint64_t* b) {
        uint64_t c = *a;
        *a = *b;
        *b = c;
        return;
}
