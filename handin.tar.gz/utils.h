#include <iostream>
#include <atomic>
#include <queue>
#include <mutex>
#include <thread>
#include <stdlib.h>     /* srand, rand */
#include <time.h>       /* time */
#include <vector>
#include <condition_variable>
#include <array>
#include <pthread.h>
#include <assert.h>

using namespace std;

const uint64_t queue_uint64_thres = 1 << 11;

struct config_t {
/* read only variables */
	uint64_t  nodes;		// # of nodes
	uint64_t  level;	        // # of levels
	uint64_t  groups;	 	// # of groups
	uint64_t* map_table;	 	// # shuffled mapping table
	uint64_t  total_threads;	// # of threads, defined by user
        uint64_t  wmax;
        uint64_t  thres;
	uint64_t  period;
	uint64_t* group_size;
/* shared variables */
	std::atomic<uint64_t> finished_threads;

//	uint64_t finished_threads;
	uint64_t** pa;	// physical address
	uint64_t failed_nodes;	// # of failed nodes
	std::queue<uint64_t>* req_queue;
	std::mutex* group_lock; // 1 lock per group
//	pthread_mutex_t* 	group_lock;
	uint64_t* group_counter;
	uint64_t* group_writes;
        uint64_t* start;
        uint64_t* gap;
        std::condition_variable_any cv_producer; 
	std::condition_variable_any cv_consumer;
        std::mutex mutex;	// queue lock 
//	pthread_mutex_t mutex;
//	pthread_cond_t cv_producer;
//	pthread_cond_t cv_consumer;
};
void produce_path_oram_requests(config_t* config);
void consume_path_oram_requests(config_t* config);
int increment_memory_line(uint64_t la, config_t* config);
inline void leaf_range(uint64_t level, uint64_t &from, uint64_t &to);
inline uint64_t binarySearch(uint64_t arr[], uint64_t l, uint64_t r, uint64_t x);
